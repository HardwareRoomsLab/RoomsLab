
#ifndef DOORLOCK_H_
#define DOORLOCK_H_

#include "..\srcC\sc_types.h"
		
#ifdef __cplusplus
extern "C" { 
#endif 

/*! \file Header of the state machine 'Doorlock'.
*/

/*! Enumeration of all states */ 
typedef enum
{
	Doorlock_main_region_Init,
	Doorlock_main_region_WaitConnect,
	Doorlock_main_region_Work,
	Doorlock_main_region_Work_Transmitter_Idle,
	Doorlock_main_region_Work_Transmitter_CommandExec,
	Doorlock_main_region_Work_Transmitter_SendTimeout,
	Doorlock_main_region_Work_Transmitter_CommandSucc,
	Doorlock_main_region_Work_Buttons_Idle,
	Doorlock_main_region_Work_Buttons_Pressed,
	Doorlock_main_region_Work_Locks_Open,
	Doorlock_main_region_Work_Locks_Closed,
	Doorlock_main_region_Work_Locks_inProcess,
	Doorlock_main_region_Work_Door__reeds__Open,
	Doorlock_main_region_Work_Door__reeds__Closed,
	Doorlock_main_region_Work_Door__reeds__Undefined,
	Doorlock_main_region_Work_Led_Off,
	Doorlock_main_region_Work_Led_On,
	Doorlock_main_region_Work_Led_Blinking1,
	Doorlock_main_region_Work_Led_Blinking2,
	Doorlock_main_region_Configure,
	Doorlock_last_state
} DoorlockStates;

/* Declaration of constants for scope DoorlockIface. */
extern const sc_integer DOORLOCK_DOORLOCKIFACE_ON;
extern const sc_integer DOORLOCK_DOORLOCKIFACE_OFF;
extern const sc_integer DOORLOCK_DOORLOCKIFACE_UNDEFINED;

/*! Type definition of the data structure for the DoorlockInternal interface scope. */
typedef struct
{
	sc_boolean Initiated_raised;
	sc_boolean Connected_raised;
	sc_boolean Unconnected_raised;
	sc_boolean Configure_raised;
} DoorlockInternal;

/*! Type definition of the data structure for the DoorlockIfaceDoor interface scope. */
typedef struct
{
	sc_integer doorState;
	sc_boolean GOpenedOn_raised;
	sc_boolean GOpenedOff_raised;
	sc_boolean GClosedOn_raised;
	sc_boolean GClosedOff_raised;
} DoorlockIfaceDoor;

/*! Type definition of the data structure for the DoorlockIfaceLed interface scope. */
typedef struct
{
	sc_integer ledState;
	sc_boolean LedOn_raised;
	sc_boolean LedOff_raised;
	sc_boolean LedBlinking1_raised;
	sc_boolean LedBlinking2_raised;
} DoorlockIfaceLed;

/* Declaration of constants for scope DoorlockIfaceLed. */
extern const sc_integer DOORLOCK_DOORLOCKIFACELED_BLINKING;

/*! Type definition of the data structure for the DoorlockIfaceLock interface scope. */
typedef struct
{
	sc_integer lockState;
	sc_boolean LockOn_raised;
	sc_boolean LockOff_raised;
	sc_boolean ChangeState_raised;
} DoorlockIfaceLock;

/*! Type definition of the data structure for the DoorlockIfaceButtons interface scope. */
typedef struct
{
	sc_boolean staffReed_raised;
	sc_boolean OutButton_raised;
	sc_boolean Command_raised;
} DoorlockIfaceButtons;

/*! Type definition of the data structure for the DoorlockIfaceTrans interface scope. */
typedef struct
{
	sc_boolean command_raised;
	sc_boolean eventInt_raised;
	sc_boolean timeout_raised;
	sc_boolean comComplete_raised;
	sc_boolean sent_raised;
} DoorlockIfaceTrans;

/*! Type definition of the data structure for the DoorlockIfaceCommands interface scope. */
typedef struct
{
	sc_integer command;
	sc_integer timeout;
} DoorlockIfaceCommands;

/* Declaration of constants for scope DoorlockIfaceCommands. */
extern const sc_integer DOORLOCK_DOORLOCKIFACECOMMANDS_OPEN;
extern const sc_integer DOORLOCK_DOORLOCKIFACECOMMANDS_CLOSE;
extern const sc_integer DOORLOCK_DOORLOCKIFACECOMMANDS_GIVE_STATUS;
extern const sc_integer DOORLOCK_DOORLOCKIFACECOMMANDS_OPEN_TM;
extern const sc_integer DOORLOCK_DOORLOCKIFACECOMMANDS_CLOSE_TM;

/*! Type definition of the data structure for the DoorlockTimeEvents interface scope. */
typedef struct
{
	sc_boolean doorlock_main_region_WaitConnect_tev0_raised;
	sc_boolean doorlock_main_region_Work_Transmitter_CommandExec_tev0_raised;
	sc_boolean doorlock_main_region_Work_Buttons_Pressed_tev0_raised;
} DoorlockTimeEvents;


/*! Define dimension of the state configuration vector for orthogonal states. */
#define DOORLOCK_MAX_ORTHOGONAL_STATES 5

/*! 
 * Type definition of the data structure for the Doorlock state machine.
 * This data structure has to be allocated by the client code. 
 */
typedef struct
{
	DoorlockStates stateConfVector[DOORLOCK_MAX_ORTHOGONAL_STATES];
	sc_ushort stateConfVectorPosition; 
	
	DoorlockInternal internal;
	DoorlockIfaceDoor ifaceDoor;
	DoorlockIfaceLed ifaceLed;
	DoorlockIfaceLock ifaceLock;
	DoorlockIfaceButtons ifaceButtons;
	DoorlockIfaceTrans ifaceTrans;
	DoorlockIfaceCommands ifaceCommands;
	DoorlockTimeEvents timeEvents;
} Doorlock;

/*! Initializes the Doorlock state machine data structures. Must be called before first usage.*/
extern void doorlock_init(Doorlock* handle);

/*! Activates the state machine */
extern void doorlock_enter(Doorlock* handle);

/*! Deactivates the state machine */
extern void doorlock_exit(Doorlock* handle);

/*! Performs a 'run to completion' step. */
extern void doorlock_runCycle(Doorlock* handle);

/*! Raises a time event. */
extern void doorlock_raiseTimeEvent(const Doorlock* handle, sc_eventid evid);

/*! Gets the value of the variable 'ON' that is defined in the default interface scope. */ 
extern const sc_integer doorlockIface_get_oN(const Doorlock* handle);
/*! Gets the value of the variable 'OFF' that is defined in the default interface scope. */ 
extern const sc_integer doorlockIface_get_oFF(const Doorlock* handle);
/*! Gets the value of the variable 'UNDEFINED' that is defined in the default interface scope. */ 
extern const sc_integer doorlockIface_get_uNDEFINED(const Doorlock* handle);
/*! Gets the value of the variable 'doorState' that is defined in the interface scope 'Door'. */ 
extern sc_integer doorlockIfaceDoor_get_doorState(const Doorlock* handle);
/*! Sets the value of the variable 'doorState' that is defined in the interface scope 'Door'. */ 
extern void doorlockIfaceDoor_set_doorState(Doorlock* handle, sc_integer value);
/*! Raises the in event 'GOpenedOn' that is defined in the interface scope 'Door'. */ 
extern void doorlockIfaceDoor_raise_gOpenedOn(Doorlock* handle);

/*! Raises the in event 'GOpenedOff' that is defined in the interface scope 'Door'. */ 
extern void doorlockIfaceDoor_raise_gOpenedOff(Doorlock* handle);

/*! Raises the in event 'GClosedOn' that is defined in the interface scope 'Door'. */ 
extern void doorlockIfaceDoor_raise_gClosedOn(Doorlock* handle);

/*! Raises the in event 'GClosedOff' that is defined in the interface scope 'Door'. */ 
extern void doorlockIfaceDoor_raise_gClosedOff(Doorlock* handle);

/*! Gets the value of the variable 'ledState' that is defined in the interface scope 'Led'. */ 
extern sc_integer doorlockIfaceLed_get_ledState(const Doorlock* handle);
/*! Sets the value of the variable 'ledState' that is defined in the interface scope 'Led'. */ 
extern void doorlockIfaceLed_set_ledState(Doorlock* handle, sc_integer value);
/*! Gets the value of the variable 'BLINKING' that is defined in the interface scope 'Led'. */ 
extern const sc_integer doorlockIfaceLed_get_bLINKING(const Doorlock* handle);
/*! Raises the in event 'LedOn' that is defined in the interface scope 'Led'. */ 
extern void doorlockIfaceLed_raise_ledOn(Doorlock* handle);

/*! Raises the in event 'LedOff' that is defined in the interface scope 'Led'. */ 
extern void doorlockIfaceLed_raise_ledOff(Doorlock* handle);

/*! Raises the in event 'LedBlinking1' that is defined in the interface scope 'Led'. */ 
extern void doorlockIfaceLed_raise_ledBlinking1(Doorlock* handle);

/*! Raises the in event 'LedBlinking2' that is defined in the interface scope 'Led'. */ 
extern void doorlockIfaceLed_raise_ledBlinking2(Doorlock* handle);

/*! Gets the value of the variable 'lockState' that is defined in the interface scope 'Lock'. */ 
extern sc_integer doorlockIfaceLock_get_lockState(const Doorlock* handle);
/*! Sets the value of the variable 'lockState' that is defined in the interface scope 'Lock'. */ 
extern void doorlockIfaceLock_set_lockState(Doorlock* handle, sc_integer value);
/*! Raises the in event 'LockOn' that is defined in the interface scope 'Lock'. */ 
extern void doorlockIfaceLock_raise_lockOn(Doorlock* handle);

/*! Raises the in event 'LockOff' that is defined in the interface scope 'Lock'. */ 
extern void doorlockIfaceLock_raise_lockOff(Doorlock* handle);

/*! Raises the in event 'ChangeState' that is defined in the interface scope 'Lock'. */ 
extern void doorlockIfaceLock_raise_changeState(Doorlock* handle);

/*! Raises the in event 'staffReed' that is defined in the interface scope 'Buttons'. */ 
extern void doorlockIfaceButtons_raise_staffReed(Doorlock* handle);

/*! Raises the in event 'OutButton' that is defined in the interface scope 'Buttons'. */ 
extern void doorlockIfaceButtons_raise_outButton(Doorlock* handle);

/*! Raises the in event 'Command' that is defined in the interface scope 'Buttons'. */ 
extern void doorlockIfaceButtons_raise_command(Doorlock* handle);

/*! Raises the in event 'command' that is defined in the interface scope 'Trans'. */ 
extern void doorlockIfaceTrans_raise_command(Doorlock* handle);

/*! Checks if the out event 'eventInt' that is defined in the interface scope 'Trans' has been raised. */ 
extern sc_boolean doorlockIfaceTrans_israised_eventInt(const Doorlock* handle);

/*! Checks if the out event 'timeout' that is defined in the interface scope 'Trans' has been raised. */ 
extern sc_boolean doorlockIfaceTrans_israised_timeout(const Doorlock* handle);

/*! Raises the in event 'comComplete' that is defined in the interface scope 'Trans'. */ 
extern void doorlockIfaceTrans_raise_comComplete(Doorlock* handle);

/*! Raises the in event 'sent' that is defined in the interface scope 'Trans'. */ 
extern void doorlockIfaceTrans_raise_sent(Doorlock* handle);

/*! Gets the value of the variable 'command' that is defined in the interface scope 'Commands'. */ 
extern sc_integer doorlockIfaceCommands_get_command(const Doorlock* handle);
/*! Sets the value of the variable 'command' that is defined in the interface scope 'Commands'. */ 
extern void doorlockIfaceCommands_set_command(Doorlock* handle, sc_integer value);
/*! Gets the value of the variable 'OPEN' that is defined in the interface scope 'Commands'. */ 
extern const sc_integer doorlockIfaceCommands_get_oPEN(const Doorlock* handle);
/*! Gets the value of the variable 'CLOSE' that is defined in the interface scope 'Commands'. */ 
extern const sc_integer doorlockIfaceCommands_get_cLOSE(const Doorlock* handle);
/*! Gets the value of the variable 'GIVE_STATUS' that is defined in the interface scope 'Commands'. */ 
extern const sc_integer doorlockIfaceCommands_get_gIVE_STATUS(const Doorlock* handle);
/*! Gets the value of the variable 'timeout' that is defined in the interface scope 'Commands'. */ 
extern sc_integer doorlockIfaceCommands_get_timeout(const Doorlock* handle);
/*! Sets the value of the variable 'timeout' that is defined in the interface scope 'Commands'. */ 
extern void doorlockIfaceCommands_set_timeout(Doorlock* handle, sc_integer value);
/*! Gets the value of the variable 'OPEN_TM' that is defined in the interface scope 'Commands'. */ 
extern const sc_integer doorlockIfaceCommands_get_oPEN_TM(const Doorlock* handle);
/*! Gets the value of the variable 'CLOSE_TM' that is defined in the interface scope 'Commands'. */ 
extern const sc_integer doorlockIfaceCommands_get_cLOSE_TM(const Doorlock* handle);

/*!
 * Checks whether the state machine is active (until 2.4.1 this method was used for states).
 * A state machine is active if it was entered. It is inactive if it has not been entered at all or if it has been exited.
 */
extern sc_boolean doorlock_isActive(const Doorlock* handle);

/*!
 * Checks if all active states are final. 
 * If there are no active states then the state machine is considered being inactive. In this case this method returns false.
 */
extern sc_boolean doorlock_isFinal(const Doorlock* handle);

/*! Checks if the specified state is active (until 2.4.1 the used method for states was called isActive()). */
extern sc_boolean doorlock_isStateActive(const Doorlock* handle, DoorlockStates state);

#ifdef __cplusplus
}
#endif 

#endif /* DOORLOCK_H_ */
