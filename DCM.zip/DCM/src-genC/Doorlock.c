
#include <stdlib.h>
#include <string.h>
#include "..\srcC\sc_types.h"
#include "Doorlock.h"
#include "DoorlockRequired.h"
/*! \file Implementation of the state machine 'Doorlock'
*/

/* prototypes of all internal functions */
static sc_boolean doorlock_check_main_region_Init_tr0_tr0(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_WaitConnect_tr0_tr0(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_WaitConnect_tr1_tr1(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_WaitConnect_tr2_tr2(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Transmitter_Idle_tr0_tr0(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Transmitter_CommandExec_tr0_tr0(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Transmitter_CommandExec_tr1_tr1(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Transmitter_SendTimeout_tr0_tr0(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Transmitter_CommandSucc_tr0_tr0(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Buttons_Idle_tr0_tr0(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Buttons_Idle_tr1_tr1(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Buttons_Pressed_tr0_tr0(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Locks_Open_tr0_tr0(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Locks_Open_tr1_tr1(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Locks_Closed_tr0_tr0(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Locks_Closed_tr1_tr1(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Locks_inProcess_tr0_tr0(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Locks_inProcess_tr1_tr1(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Door__reeds__Open_tr0_tr0(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Door__reeds__Closed_tr0_tr0(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Door__reeds__Undefined_tr0_tr0(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Door__reeds__Undefined_tr1_tr1(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Led_Off_tr0_tr0(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Led_Off_tr1_tr1(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Led_Off_tr2_tr2(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Led_On_tr0_tr0(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Led_Blinking1_tr0_tr0(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Led_Blinking1_tr1_tr1(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Led_Blinking2_tr0_tr0(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Work_Led_Blinking2_tr1_tr1(const Doorlock* handle);
static sc_boolean doorlock_check_main_region_Configure_tr0_tr0(const Doorlock* handle);
static void doorlock_effect_main_region_Init_tr0(Doorlock* handle);
static void doorlock_effect_main_region_WaitConnect_tr0(Doorlock* handle);
static void doorlock_effect_main_region_WaitConnect_tr1(Doorlock* handle);
static void doorlock_effect_main_region_WaitConnect_tr2(Doorlock* handle);
static void doorlock_effect_main_region_Work_Transmitter_Idle_tr0(Doorlock* handle);
static void doorlock_effect_main_region_Work_Transmitter_CommandExec_tr0(Doorlock* handle);
static void doorlock_effect_main_region_Work_Transmitter_CommandExec_tr1(Doorlock* handle);
static void doorlock_effect_main_region_Work_Transmitter_SendTimeout_tr0(Doorlock* handle);
static void doorlock_effect_main_region_Work_Transmitter_CommandSucc_tr0(Doorlock* handle);
static void doorlock_effect_main_region_Work_Buttons_Idle_tr0(Doorlock* handle);
static void doorlock_effect_main_region_Work_Buttons_Idle_tr1(Doorlock* handle);
static void doorlock_effect_main_region_Work_Buttons_Pressed_tr0(Doorlock* handle);
static void doorlock_effect_main_region_Work_Locks_Open_tr0(Doorlock* handle);
static void doorlock_effect_main_region_Work_Locks_Open_tr1(Doorlock* handle);
static void doorlock_effect_main_region_Work_Locks_Closed_tr0(Doorlock* handle);
static void doorlock_effect_main_region_Work_Locks_Closed_tr1(Doorlock* handle);
static void doorlock_effect_main_region_Work_Locks_inProcess_tr0(Doorlock* handle);
static void doorlock_effect_main_region_Work_Locks_inProcess_tr1(Doorlock* handle);
static void doorlock_effect_main_region_Work_Door__reeds__Open_tr0(Doorlock* handle);
static void doorlock_effect_main_region_Work_Door__reeds__Closed_tr0(Doorlock* handle);
static void doorlock_effect_main_region_Work_Door__reeds__Undefined_tr0(Doorlock* handle);
static void doorlock_effect_main_region_Work_Door__reeds__Undefined_tr1(Doorlock* handle);
static void doorlock_effect_main_region_Work_Led_Off_tr0(Doorlock* handle);
static void doorlock_effect_main_region_Work_Led_Off_tr1(Doorlock* handle);
static void doorlock_effect_main_region_Work_Led_Off_tr2(Doorlock* handle);
static void doorlock_effect_main_region_Work_Led_On_tr0(Doorlock* handle);
static void doorlock_effect_main_region_Work_Led_Blinking1_tr0(Doorlock* handle);
static void doorlock_effect_main_region_Work_Led_Blinking1_tr1(Doorlock* handle);
static void doorlock_effect_main_region_Work_Led_Blinking2_tr0(Doorlock* handle);
static void doorlock_effect_main_region_Work_Led_Blinking2_tr1(Doorlock* handle);
static void doorlock_effect_main_region_Configure_tr0(Doorlock* handle);
static void doorlock_enact_main_region_WaitConnect(Doorlock* handle);
static void doorlock_enact_main_region_Work_Transmitter_CommandExec(Doorlock* handle);
static void doorlock_enact_main_region_Work_Buttons_Pressed(Doorlock* handle);
static void doorlock_enact_main_region_Work_Locks_Open(Doorlock* handle);
static void doorlock_enact_main_region_Work_Locks_Closed(Doorlock* handle);
static void doorlock_enact_main_region_Work_Door__reeds__Open(Doorlock* handle);
static void doorlock_enact_main_region_Work_Door__reeds__Closed(Doorlock* handle);
static void doorlock_enact_main_region_Work_Door__reeds__Undefined(Doorlock* handle);
static void doorlock_exact_main_region_WaitConnect(Doorlock* handle);
static void doorlock_exact_main_region_Work_Transmitter_CommandExec(Doorlock* handle);
static void doorlock_exact_main_region_Work_Buttons_Pressed(Doorlock* handle);
static void doorlock_exact_main_region_Work_Locks_Open(Doorlock* handle);
static void doorlock_exact_main_region_Work_Locks_Closed(Doorlock* handle);
static void doorlock_enseq_main_region_Init_default(Doorlock* handle);
static void doorlock_enseq_main_region_WaitConnect_default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_Transmitter_Idle_default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_Transmitter_CommandExec_default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_Transmitter_SendTimeout_default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_Transmitter_CommandSucc_default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_Buttons_Idle_default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_Buttons_Pressed_default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_Locks_Open_default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_Locks_Closed_default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_Locks_inProcess_default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_Door__reeds__Open_default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_Door__reeds__Closed_default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_Door__reeds__Undefined_default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_Led_Off_default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_Led_On_default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_Led_Blinking1_default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_Led_Blinking2_default(Doorlock* handle);
static void doorlock_enseq_main_region_Configure_default(Doorlock* handle);
static void doorlock_enseq_main_region_default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_Transmitter_default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_Buttons_default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_Locks_default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_Door__reeds__default(Doorlock* handle);
static void doorlock_enseq_main_region_Work_Led_default(Doorlock* handle);
static void doorlock_exseq_main_region_Init(Doorlock* handle);
static void doorlock_exseq_main_region_WaitConnect(Doorlock* handle);
static void doorlock_exseq_main_region_Work_Transmitter_Idle(Doorlock* handle);
static void doorlock_exseq_main_region_Work_Transmitter_CommandExec(Doorlock* handle);
static void doorlock_exseq_main_region_Work_Transmitter_SendTimeout(Doorlock* handle);
static void doorlock_exseq_main_region_Work_Transmitter_CommandSucc(Doorlock* handle);
static void doorlock_exseq_main_region_Work_Buttons_Idle(Doorlock* handle);
static void doorlock_exseq_main_region_Work_Buttons_Pressed(Doorlock* handle);
static void doorlock_exseq_main_region_Work_Locks_Open(Doorlock* handle);
static void doorlock_exseq_main_region_Work_Locks_Closed(Doorlock* handle);
static void doorlock_exseq_main_region_Work_Locks_inProcess(Doorlock* handle);
static void doorlock_exseq_main_region_Work_Door__reeds__Open(Doorlock* handle);
static void doorlock_exseq_main_region_Work_Door__reeds__Closed(Doorlock* handle);
static void doorlock_exseq_main_region_Work_Door__reeds__Undefined(Doorlock* handle);
static void doorlock_exseq_main_region_Work_Led_Off(Doorlock* handle);
static void doorlock_exseq_main_region_Work_Led_On(Doorlock* handle);
static void doorlock_exseq_main_region_Work_Led_Blinking1(Doorlock* handle);
static void doorlock_exseq_main_region_Work_Led_Blinking2(Doorlock* handle);
static void doorlock_exseq_main_region_Configure(Doorlock* handle);
static void doorlock_exseq_main_region(Doorlock* handle);
static void doorlock_exseq_main_region_Work_Transmitter(Doorlock* handle);
static void doorlock_exseq_main_region_Work_Buttons(Doorlock* handle);
static void doorlock_exseq_main_region_Work_Locks(Doorlock* handle);
static void doorlock_exseq_main_region_Work_Door__reeds_(Doorlock* handle);
static void doorlock_exseq_main_region_Work_Led(Doorlock* handle);
static void doorlock_react_main_region_Init(Doorlock* handle);
static void doorlock_react_main_region_WaitConnect(Doorlock* handle);
static void doorlock_react_main_region_Work_Transmitter_Idle(Doorlock* handle);
static void doorlock_react_main_region_Work_Transmitter_CommandExec(Doorlock* handle);
static void doorlock_react_main_region_Work_Transmitter_SendTimeout(Doorlock* handle);
static void doorlock_react_main_region_Work_Transmitter_CommandSucc(Doorlock* handle);
static void doorlock_react_main_region_Work_Buttons_Idle(Doorlock* handle);
static void doorlock_react_main_region_Work_Buttons_Pressed(Doorlock* handle);
static void doorlock_react_main_region_Work_Locks_Open(Doorlock* handle);
static void doorlock_react_main_region_Work_Locks_Closed(Doorlock* handle);
static void doorlock_react_main_region_Work_Locks_inProcess(Doorlock* handle);
static void doorlock_react_main_region_Work_Door__reeds__Open(Doorlock* handle);
static void doorlock_react_main_region_Work_Door__reeds__Closed(Doorlock* handle);
static void doorlock_react_main_region_Work_Door__reeds__Undefined(Doorlock* handle);
static void doorlock_react_main_region_Work_Led_Off(Doorlock* handle);
static void doorlock_react_main_region_Work_Led_On(Doorlock* handle);
static void doorlock_react_main_region_Work_Led_Blinking1(Doorlock* handle);
static void doorlock_react_main_region_Work_Led_Blinking2(Doorlock* handle);
static void doorlock_react_main_region_Configure(Doorlock* handle);
static void doorlock_react_main_region__entry_Default(Doorlock* handle);
static void doorlock_react_main_region_Work_Transmitter__entry_Default(Doorlock* handle);
static void doorlock_react_main_region_Work_Buttons__entry_Default(Doorlock* handle);
static void doorlock_react_main_region_Work_Locks__entry_Default(Doorlock* handle);
static void doorlock_react_main_region_Work_Door__reeds___entry_Default(Doorlock* handle);
static void doorlock_react_main_region_Work_Led__entry_Default(Doorlock* handle);
static void doorlock_clearInEvents(Doorlock* handle);
static void doorlock_clearOutEvents(Doorlock* handle);

const sc_integer DOORLOCK_DOORLOCKIFACE_ON = 1;
const sc_integer DOORLOCK_DOORLOCKIFACE_OFF = 2;
const sc_integer DOORLOCK_DOORLOCKIFACE_UNDEFINED = 3;
const sc_integer DOORLOCK_DOORLOCKIFACELED_BLINKING = 13;
const sc_integer DOORLOCK_DOORLOCKIFACECOMMANDS_OPEN = 1;
const sc_integer DOORLOCK_DOORLOCKIFACECOMMANDS_CLOSE = 2;
const sc_integer DOORLOCK_DOORLOCKIFACECOMMANDS_GIVE_STATUS = 3;
const sc_integer DOORLOCK_DOORLOCKIFACECOMMANDS_OPEN_TM = 5;
const sc_integer DOORLOCK_DOORLOCKIFACECOMMANDS_CLOSE_TM = 5;

void doorlock_init(Doorlock* handle)
{
	sc_integer i;

	for (i = 0; i < DOORLOCK_MAX_ORTHOGONAL_STATES; ++i)
	{
		handle->stateConfVector[i] = Doorlock_last_state;
	}
	
	
	handle->stateConfVectorPosition = 0;

	doorlock_clearInEvents(handle);
	doorlock_clearOutEvents(handle);

	/* Default init sequence for statechart Doorlock */
	handle->ifaceDoor.doorState = 0;
	handle->ifaceLed.ledState = 0;
	handle->ifaceLock.lockState = 0;
	handle->ifaceCommands.command = 0;
	handle->ifaceCommands.timeout = 0;

}

void doorlock_enter(Doorlock* handle)
{
	/* Default enter sequence for statechart Doorlock */
	doorlock_enseq_main_region_default(handle);
}

void doorlock_exit(Doorlock* handle)
{
	/* Default exit sequence for statechart Doorlock */
	doorlock_exseq_main_region(handle);
}

sc_boolean doorlock_isActive(const Doorlock* handle)
{
	sc_boolean result;
	if (handle->stateConfVector[0] != Doorlock_last_state || handle->stateConfVector[1] != Doorlock_last_state || handle->stateConfVector[2] != Doorlock_last_state || handle->stateConfVector[3] != Doorlock_last_state || handle->stateConfVector[4] != Doorlock_last_state)
	{
		result =  bool_true;
	}
	else
	{
		result = bool_false;
	}
	return result;
}

/* 
 * Always returns 'false' since this state machine can never become final.
 */
sc_boolean doorlock_isFinal(const Doorlock* handle)
{
   return bool_false;
}

static void doorlock_clearInEvents(Doorlock* handle)
{
	handle->ifaceDoor.GOpenedOn_raised = bool_false;
	handle->ifaceDoor.GOpenedOff_raised = bool_false;
	handle->ifaceDoor.GClosedOn_raised = bool_false;
	handle->ifaceDoor.GClosedOff_raised = bool_false;
	handle->ifaceLed.LedOn_raised = bool_false;
	handle->ifaceLed.LedOff_raised = bool_false;
	handle->ifaceLed.LedBlinking1_raised = bool_false;
	handle->ifaceLed.LedBlinking2_raised = bool_false;
	handle->ifaceLock.LockOn_raised = bool_false;
	handle->ifaceLock.LockOff_raised = bool_false;
	handle->ifaceLock.ChangeState_raised = bool_false;
	handle->ifaceButtons.staffReed_raised = bool_false;
	handle->ifaceButtons.OutButton_raised = bool_false;
	handle->ifaceButtons.Command_raised = bool_false;
	handle->ifaceTrans.command_raised = bool_false;
	handle->ifaceTrans.comComplete_raised = bool_false;
	handle->ifaceTrans.sent_raised = bool_false;
	handle->internal.Initiated_raised = bool_false;
	handle->internal.Connected_raised = bool_false;
	handle->internal.Unconnected_raised = bool_false;
	handle->internal.Configure_raised = bool_false;
	handle->timeEvents.doorlock_main_region_WaitConnect_tev0_raised = bool_false;
	handle->timeEvents.doorlock_main_region_Work_Transmitter_CommandExec_tev0_raised = bool_false;
	handle->timeEvents.doorlock_main_region_Work_Buttons_Pressed_tev0_raised = bool_false;
}

static void doorlock_clearOutEvents(Doorlock* handle)
{
	handle->ifaceTrans.eventInt_raised = bool_false;
	handle->ifaceTrans.timeout_raised = bool_false;
}

void doorlock_runCycle(Doorlock* handle)
{
	
	doorlock_clearOutEvents(handle);
	
	for (handle->stateConfVectorPosition = 0;
		handle->stateConfVectorPosition < DOORLOCK_MAX_ORTHOGONAL_STATES;
		handle->stateConfVectorPosition++)
		{
			
		switch (handle->stateConfVector[handle->stateConfVectorPosition])
		{
		case Doorlock_main_region_Init :
		{
			doorlock_react_main_region_Init(handle);
			break;
		}
		case Doorlock_main_region_WaitConnect :
		{
			doorlock_react_main_region_WaitConnect(handle);
			break;
		}
		case Doorlock_main_region_Work_Transmitter_Idle :
		{
			doorlock_react_main_region_Work_Transmitter_Idle(handle);
			break;
		}
		case Doorlock_main_region_Work_Transmitter_CommandExec :
		{
			doorlock_react_main_region_Work_Transmitter_CommandExec(handle);
			break;
		}
		case Doorlock_main_region_Work_Transmitter_SendTimeout :
		{
			doorlock_react_main_region_Work_Transmitter_SendTimeout(handle);
			break;
		}
		case Doorlock_main_region_Work_Transmitter_CommandSucc :
		{
			doorlock_react_main_region_Work_Transmitter_CommandSucc(handle);
			break;
		}
		case Doorlock_main_region_Work_Buttons_Idle :
		{
			doorlock_react_main_region_Work_Buttons_Idle(handle);
			break;
		}
		case Doorlock_main_region_Work_Buttons_Pressed :
		{
			doorlock_react_main_region_Work_Buttons_Pressed(handle);
			break;
		}
		case Doorlock_main_region_Work_Locks_Open :
		{
			doorlock_react_main_region_Work_Locks_Open(handle);
			break;
		}
		case Doorlock_main_region_Work_Locks_Closed :
		{
			doorlock_react_main_region_Work_Locks_Closed(handle);
			break;
		}
		case Doorlock_main_region_Work_Locks_inProcess :
		{
			doorlock_react_main_region_Work_Locks_inProcess(handle);
			break;
		}
		case Doorlock_main_region_Work_Door__reeds__Open :
		{
			doorlock_react_main_region_Work_Door__reeds__Open(handle);
			break;
		}
		case Doorlock_main_region_Work_Door__reeds__Closed :
		{
			doorlock_react_main_region_Work_Door__reeds__Closed(handle);
			break;
		}
		case Doorlock_main_region_Work_Door__reeds__Undefined :
		{
			doorlock_react_main_region_Work_Door__reeds__Undefined(handle);
			break;
		}
		case Doorlock_main_region_Work_Led_Off :
		{
			doorlock_react_main_region_Work_Led_Off(handle);
			break;
		}
		case Doorlock_main_region_Work_Led_On :
		{
			doorlock_react_main_region_Work_Led_On(handle);
			break;
		}
		case Doorlock_main_region_Work_Led_Blinking1 :
		{
			doorlock_react_main_region_Work_Led_Blinking1(handle);
			break;
		}
		case Doorlock_main_region_Work_Led_Blinking2 :
		{
			doorlock_react_main_region_Work_Led_Blinking2(handle);
			break;
		}
		case Doorlock_main_region_Configure :
		{
			doorlock_react_main_region_Configure(handle);
			break;
		}
		default:
			break;
		}
	}
	
	doorlock_clearInEvents(handle);
}

void doorlock_raiseTimeEvent(const Doorlock* handle, sc_eventid evid)
{
	if ( ((sc_intptr_t)evid) >= ((sc_intptr_t)&(handle->timeEvents))
		&&  ((sc_intptr_t)evid) < ((sc_intptr_t)&(handle->timeEvents)) + sizeof(DoorlockTimeEvents))
		{
		*(sc_boolean*)evid = bool_true;
	}		
}

sc_boolean doorlock_isStateActive(const Doorlock* handle, DoorlockStates state)
{
	sc_boolean result = bool_false;
	switch (state)
	{
		case Doorlock_main_region_Init :
			result = (sc_boolean) (handle->stateConfVector[0] == Doorlock_main_region_Init
			);
			break;
		case Doorlock_main_region_WaitConnect :
			result = (sc_boolean) (handle->stateConfVector[0] == Doorlock_main_region_WaitConnect
			);
			break;
		case Doorlock_main_region_Work :
			result = (sc_boolean) (handle->stateConfVector[0] >= Doorlock_main_region_Work
				&& handle->stateConfVector[0] <= Doorlock_main_region_Work_Led_Blinking2);
			break;
		case Doorlock_main_region_Work_Transmitter_Idle :
			result = (sc_boolean) (handle->stateConfVector[0] == Doorlock_main_region_Work_Transmitter_Idle
			);
			break;
		case Doorlock_main_region_Work_Transmitter_CommandExec :
			result = (sc_boolean) (handle->stateConfVector[0] == Doorlock_main_region_Work_Transmitter_CommandExec
			);
			break;
		case Doorlock_main_region_Work_Transmitter_SendTimeout :
			result = (sc_boolean) (handle->stateConfVector[0] == Doorlock_main_region_Work_Transmitter_SendTimeout
			);
			break;
		case Doorlock_main_region_Work_Transmitter_CommandSucc :
			result = (sc_boolean) (handle->stateConfVector[0] == Doorlock_main_region_Work_Transmitter_CommandSucc
			);
			break;
		case Doorlock_main_region_Work_Buttons_Idle :
			result = (sc_boolean) (handle->stateConfVector[1] == Doorlock_main_region_Work_Buttons_Idle
			);
			break;
		case Doorlock_main_region_Work_Buttons_Pressed :
			result = (sc_boolean) (handle->stateConfVector[1] == Doorlock_main_region_Work_Buttons_Pressed
			);
			break;
		case Doorlock_main_region_Work_Locks_Open :
			result = (sc_boolean) (handle->stateConfVector[2] == Doorlock_main_region_Work_Locks_Open
			);
			break;
		case Doorlock_main_region_Work_Locks_Closed :
			result = (sc_boolean) (handle->stateConfVector[2] == Doorlock_main_region_Work_Locks_Closed
			);
			break;
		case Doorlock_main_region_Work_Locks_inProcess :
			result = (sc_boolean) (handle->stateConfVector[2] == Doorlock_main_region_Work_Locks_inProcess
			);
			break;
		case Doorlock_main_region_Work_Door__reeds__Open :
			result = (sc_boolean) (handle->stateConfVector[3] == Doorlock_main_region_Work_Door__reeds__Open
			);
			break;
		case Doorlock_main_region_Work_Door__reeds__Closed :
			result = (sc_boolean) (handle->stateConfVector[3] == Doorlock_main_region_Work_Door__reeds__Closed
			);
			break;
		case Doorlock_main_region_Work_Door__reeds__Undefined :
			result = (sc_boolean) (handle->stateConfVector[3] == Doorlock_main_region_Work_Door__reeds__Undefined
			);
			break;
		case Doorlock_main_region_Work_Led_Off :
			result = (sc_boolean) (handle->stateConfVector[4] == Doorlock_main_region_Work_Led_Off
			);
			break;
		case Doorlock_main_region_Work_Led_On :
			result = (sc_boolean) (handle->stateConfVector[4] == Doorlock_main_region_Work_Led_On
			);
			break;
		case Doorlock_main_region_Work_Led_Blinking1 :
			result = (sc_boolean) (handle->stateConfVector[4] == Doorlock_main_region_Work_Led_Blinking1
			);
			break;
		case Doorlock_main_region_Work_Led_Blinking2 :
			result = (sc_boolean) (handle->stateConfVector[4] == Doorlock_main_region_Work_Led_Blinking2
			);
			break;
		case Doorlock_main_region_Configure :
			result = (sc_boolean) (handle->stateConfVector[0] == Doorlock_main_region_Configure
			);
			break;
		default:
			result = bool_false;
			break;
	}
	return result;
}



const sc_integer doorlockIface_get_oN(const Doorlock* handle)
{
	return DOORLOCK_DOORLOCKIFACE_ON;
}
const sc_integer doorlockIface_get_oFF(const Doorlock* handle)
{
	return DOORLOCK_DOORLOCKIFACE_OFF;
}
const sc_integer doorlockIface_get_uNDEFINED(const Doorlock* handle)
{
	return DOORLOCK_DOORLOCKIFACE_UNDEFINED;
}
void doorlockIfaceDoor_raise_gOpenedOn(Doorlock* handle)
{
	handle->ifaceDoor.GOpenedOn_raised = bool_true;
}
void doorlockIfaceDoor_raise_gOpenedOff(Doorlock* handle)
{
	handle->ifaceDoor.GOpenedOff_raised = bool_true;
}
void doorlockIfaceDoor_raise_gClosedOn(Doorlock* handle)
{
	handle->ifaceDoor.GClosedOn_raised = bool_true;
}
void doorlockIfaceDoor_raise_gClosedOff(Doorlock* handle)
{
	handle->ifaceDoor.GClosedOff_raised = bool_true;
}


sc_integer doorlockIfaceDoor_get_doorState(const Doorlock* handle)
{
	return handle->ifaceDoor.doorState;
}
void doorlockIfaceDoor_set_doorState(Doorlock* handle, sc_integer value)
{
	handle->ifaceDoor.doorState = value;
}
void doorlockIfaceLed_raise_ledOn(Doorlock* handle)
{
	handle->ifaceLed.LedOn_raised = bool_true;
}
void doorlockIfaceLed_raise_ledOff(Doorlock* handle)
{
	handle->ifaceLed.LedOff_raised = bool_true;
}
void doorlockIfaceLed_raise_ledBlinking1(Doorlock* handle)
{
	handle->ifaceLed.LedBlinking1_raised = bool_true;
}
void doorlockIfaceLed_raise_ledBlinking2(Doorlock* handle)
{
	handle->ifaceLed.LedBlinking2_raised = bool_true;
}


sc_integer doorlockIfaceLed_get_ledState(const Doorlock* handle)
{
	return handle->ifaceLed.ledState;
}
void doorlockIfaceLed_set_ledState(Doorlock* handle, sc_integer value)
{
	handle->ifaceLed.ledState = value;
}
const sc_integer doorlockIfaceLed_get_bLINKING(const Doorlock* handle)
{
	return DOORLOCK_DOORLOCKIFACELED_BLINKING;
}
void doorlockIfaceLock_raise_lockOn(Doorlock* handle)
{
	handle->ifaceLock.LockOn_raised = bool_true;
}
void doorlockIfaceLock_raise_lockOff(Doorlock* handle)
{
	handle->ifaceLock.LockOff_raised = bool_true;
}
void doorlockIfaceLock_raise_changeState(Doorlock* handle)
{
	handle->ifaceLock.ChangeState_raised = bool_true;
}


sc_integer doorlockIfaceLock_get_lockState(const Doorlock* handle)
{
	return handle->ifaceLock.lockState;
}
void doorlockIfaceLock_set_lockState(Doorlock* handle, sc_integer value)
{
	handle->ifaceLock.lockState = value;
}
void doorlockIfaceButtons_raise_staffReed(Doorlock* handle)
{
	handle->ifaceButtons.staffReed_raised = bool_true;
}
void doorlockIfaceButtons_raise_outButton(Doorlock* handle)
{
	handle->ifaceButtons.OutButton_raised = bool_true;
}
void doorlockIfaceButtons_raise_command(Doorlock* handle)
{
	handle->ifaceButtons.Command_raised = bool_true;
}


void doorlockIfaceTrans_raise_command(Doorlock* handle)
{
	handle->ifaceTrans.command_raised = bool_true;
}
void doorlockIfaceTrans_raise_comComplete(Doorlock* handle)
{
	handle->ifaceTrans.comComplete_raised = bool_true;
}
void doorlockIfaceTrans_raise_sent(Doorlock* handle)
{
	handle->ifaceTrans.sent_raised = bool_true;
}

sc_boolean doorlockIfaceTrans_israised_eventInt(const Doorlock* handle)
{
	return handle->ifaceTrans.eventInt_raised;
}
sc_boolean doorlockIfaceTrans_israised_timeout(const Doorlock* handle)
{
	return handle->ifaceTrans.timeout_raised;
}



sc_integer doorlockIfaceCommands_get_command(const Doorlock* handle)
{
	return handle->ifaceCommands.command;
}
void doorlockIfaceCommands_set_command(Doorlock* handle, sc_integer value)
{
	handle->ifaceCommands.command = value;
}
const sc_integer doorlockIfaceCommands_get_oPEN(const Doorlock* handle)
{
	return DOORLOCK_DOORLOCKIFACECOMMANDS_OPEN;
}
const sc_integer doorlockIfaceCommands_get_cLOSE(const Doorlock* handle)
{
	return DOORLOCK_DOORLOCKIFACECOMMANDS_CLOSE;
}
const sc_integer doorlockIfaceCommands_get_gIVE_STATUS(const Doorlock* handle)
{
	return DOORLOCK_DOORLOCKIFACECOMMANDS_GIVE_STATUS;
}
sc_integer doorlockIfaceCommands_get_timeout(const Doorlock* handle)
{
	return handle->ifaceCommands.timeout;
}
void doorlockIfaceCommands_set_timeout(Doorlock* handle, sc_integer value)
{
	handle->ifaceCommands.timeout = value;
}
const sc_integer doorlockIfaceCommands_get_oPEN_TM(const Doorlock* handle)
{
	return DOORLOCK_DOORLOCKIFACECOMMANDS_OPEN_TM;
}
const sc_integer doorlockIfaceCommands_get_cLOSE_TM(const Doorlock* handle)
{
	return DOORLOCK_DOORLOCKIFACECOMMANDS_CLOSE_TM;
}

/* implementations of all internal functions */

static sc_boolean doorlock_check_main_region_Init_tr0_tr0(const Doorlock* handle)
{
	return handle->internal.Initiated_raised;
}

static sc_boolean doorlock_check_main_region_WaitConnect_tr0_tr0(const Doorlock* handle)
{
	return handle->internal.Connected_raised;
}

static sc_boolean doorlock_check_main_region_WaitConnect_tr1_tr1(const Doorlock* handle)
{
	return handle->timeEvents.doorlock_main_region_WaitConnect_tev0_raised;
}

static sc_boolean doorlock_check_main_region_WaitConnect_tr2_tr2(const Doorlock* handle)
{
	return handle->internal.Configure_raised;
}

static sc_boolean doorlock_check_main_region_Work_Transmitter_Idle_tr0_tr0(const Doorlock* handle)
{
	return handle->ifaceTrans.command_raised;
}

static sc_boolean doorlock_check_main_region_Work_Transmitter_CommandExec_tr0_tr0(const Doorlock* handle)
{
	return handle->timeEvents.doorlock_main_region_Work_Transmitter_CommandExec_tev0_raised;
}

static sc_boolean doorlock_check_main_region_Work_Transmitter_CommandExec_tr1_tr1(const Doorlock* handle)
{
	return handle->ifaceTrans.comComplete_raised;
}

static sc_boolean doorlock_check_main_region_Work_Transmitter_SendTimeout_tr0_tr0(const Doorlock* handle)
{
	return handle->ifaceTrans.sent_raised;
}

static sc_boolean doorlock_check_main_region_Work_Transmitter_CommandSucc_tr0_tr0(const Doorlock* handle)
{
	return handle->ifaceTrans.sent_raised;
}

static sc_boolean doorlock_check_main_region_Work_Buttons_Idle_tr0_tr0(const Doorlock* handle)
{
	return handle->ifaceButtons.staffReed_raised;
}

static sc_boolean doorlock_check_main_region_Work_Buttons_Idle_tr1_tr1(const Doorlock* handle)
{
	return handle->ifaceButtons.OutButton_raised;
}

static sc_boolean doorlock_check_main_region_Work_Buttons_Pressed_tr0_tr0(const Doorlock* handle)
{
	return handle->timeEvents.doorlock_main_region_Work_Buttons_Pressed_tev0_raised;
}

static sc_boolean doorlock_check_main_region_Work_Locks_Open_tr0_tr0(const Doorlock* handle)
{
	return handle->ifaceLock.LockOn_raised;
}

static sc_boolean doorlock_check_main_region_Work_Locks_Open_tr1_tr1(const Doorlock* handle)
{
	return handle->ifaceLock.ChangeState_raised;
}

static sc_boolean doorlock_check_main_region_Work_Locks_Closed_tr0_tr0(const Doorlock* handle)
{
	return handle->ifaceLock.LockOff_raised;
}

static sc_boolean doorlock_check_main_region_Work_Locks_Closed_tr1_tr1(const Doorlock* handle)
{
	return handle->ifaceLock.ChangeState_raised;
}

static sc_boolean doorlock_check_main_region_Work_Locks_inProcess_tr0_tr0(const Doorlock* handle)
{
	return handle->ifaceDoor.GClosedOn_raised;
}

static sc_boolean doorlock_check_main_region_Work_Locks_inProcess_tr1_tr1(const Doorlock* handle)
{
	return handle->ifaceDoor.GOpenedOn_raised;
}

static sc_boolean doorlock_check_main_region_Work_Door__reeds__Open_tr0_tr0(const Doorlock* handle)
{
	return handle->ifaceDoor.GOpenedOff_raised;
}

static sc_boolean doorlock_check_main_region_Work_Door__reeds__Closed_tr0_tr0(const Doorlock* handle)
{
	return handle->ifaceDoor.GClosedOff_raised;
}

static sc_boolean doorlock_check_main_region_Work_Door__reeds__Undefined_tr0_tr0(const Doorlock* handle)
{
	return handle->ifaceDoor.GOpenedOn_raised;
}

static sc_boolean doorlock_check_main_region_Work_Door__reeds__Undefined_tr1_tr1(const Doorlock* handle)
{
	return handle->ifaceDoor.GClosedOn_raised;
}

static sc_boolean doorlock_check_main_region_Work_Led_Off_tr0_tr0(const Doorlock* handle)
{
	return handle->ifaceLed.LedOn_raised;
}

static sc_boolean doorlock_check_main_region_Work_Led_Off_tr1_tr1(const Doorlock* handle)
{
	return handle->ifaceLed.LedBlinking1_raised;
}

static sc_boolean doorlock_check_main_region_Work_Led_Off_tr2_tr2(const Doorlock* handle)
{
	return handle->ifaceLed.LedBlinking2_raised;
}

static sc_boolean doorlock_check_main_region_Work_Led_On_tr0_tr0(const Doorlock* handle)
{
	return handle->ifaceLed.LedOff_raised;
}

static sc_boolean doorlock_check_main_region_Work_Led_Blinking1_tr0_tr0(const Doorlock* handle)
{
	return handle->ifaceLed.LedOff_raised;
}

static sc_boolean doorlock_check_main_region_Work_Led_Blinking1_tr1_tr1(const Doorlock* handle)
{
	return handle->ifaceLed.LedOn_raised;
}

static sc_boolean doorlock_check_main_region_Work_Led_Blinking2_tr0_tr0(const Doorlock* handle)
{
	return handle->ifaceLed.LedOff_raised;
}

static sc_boolean doorlock_check_main_region_Work_Led_Blinking2_tr1_tr1(const Doorlock* handle)
{
	return handle->ifaceLed.LedOn_raised;
}

static sc_boolean doorlock_check_main_region_Configure_tr0_tr0(const Doorlock* handle)
{
	return handle->internal.Connected_raised;
}

static void doorlock_effect_main_region_Init_tr0(Doorlock* handle)
{
	doorlock_exseq_main_region_Init(handle);
	doorlock_enseq_main_region_WaitConnect_default(handle);
}

static void doorlock_effect_main_region_WaitConnect_tr0(Doorlock* handle)
{
	doorlock_exseq_main_region_WaitConnect(handle);
	doorlock_enseq_main_region_Work_default(handle);
}

static void doorlock_effect_main_region_WaitConnect_tr1(Doorlock* handle)
{
	doorlock_exseq_main_region_WaitConnect(handle);
	doorlock_enseq_main_region_Work_default(handle);
}

static void doorlock_effect_main_region_WaitConnect_tr2(Doorlock* handle)
{
	doorlock_exseq_main_region_WaitConnect(handle);
	doorlock_enseq_main_region_Configure_default(handle);
}

static void doorlock_effect_main_region_Work_Transmitter_Idle_tr0(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Transmitter_Idle(handle);
	doorlock_enseq_main_region_Work_Transmitter_CommandExec_default(handle);
}

static void doorlock_effect_main_region_Work_Transmitter_CommandExec_tr0(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Transmitter_CommandExec(handle);
	doorlock_enseq_main_region_Work_Transmitter_SendTimeout_default(handle);
}

static void doorlock_effect_main_region_Work_Transmitter_CommandExec_tr1(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Transmitter_CommandExec(handle);
	doorlock_enseq_main_region_Work_Transmitter_CommandSucc_default(handle);
}

static void doorlock_effect_main_region_Work_Transmitter_SendTimeout_tr0(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Transmitter_SendTimeout(handle);
	doorlock_enseq_main_region_Work_Transmitter_Idle_default(handle);
}

static void doorlock_effect_main_region_Work_Transmitter_CommandSucc_tr0(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Transmitter_CommandSucc(handle);
	doorlock_enseq_main_region_Work_Transmitter_Idle_default(handle);
}

static void doorlock_effect_main_region_Work_Buttons_Idle_tr0(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Buttons_Idle(handle);
	doorlock_enseq_main_region_Work_Buttons_Pressed_default(handle);
}

static void doorlock_effect_main_region_Work_Buttons_Idle_tr1(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Buttons_Idle(handle);
	doorlock_enseq_main_region_Work_Buttons_Pressed_default(handle);
}

static void doorlock_effect_main_region_Work_Buttons_Pressed_tr0(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Buttons_Pressed(handle);
	doorlock_enseq_main_region_Work_Buttons_Idle_default(handle);
}

static void doorlock_effect_main_region_Work_Locks_Open_tr0(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Locks_Open(handle);
	doorlock_enseq_main_region_Work_Locks_inProcess_default(handle);
}

static void doorlock_effect_main_region_Work_Locks_Open_tr1(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Locks_Open(handle);
	doorlock_enseq_main_region_Work_Locks_inProcess_default(handle);
}

static void doorlock_effect_main_region_Work_Locks_Closed_tr0(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Locks_Closed(handle);
	doorlock_enseq_main_region_Work_Locks_inProcess_default(handle);
}

static void doorlock_effect_main_region_Work_Locks_Closed_tr1(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Locks_Closed(handle);
	doorlock_enseq_main_region_Work_Locks_inProcess_default(handle);
}

static void doorlock_effect_main_region_Work_Locks_inProcess_tr0(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Locks_inProcess(handle);
	doorlock_enseq_main_region_Work_Locks_Closed_default(handle);
}

static void doorlock_effect_main_region_Work_Locks_inProcess_tr1(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Locks_inProcess(handle);
	doorlock_enseq_main_region_Work_Locks_Open_default(handle);
}

static void doorlock_effect_main_region_Work_Door__reeds__Open_tr0(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Door__reeds__Open(handle);
	doorlock_enseq_main_region_Work_Door__reeds__Undefined_default(handle);
}

static void doorlock_effect_main_region_Work_Door__reeds__Closed_tr0(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Door__reeds__Closed(handle);
	doorlock_enseq_main_region_Work_Door__reeds__Undefined_default(handle);
}

static void doorlock_effect_main_region_Work_Door__reeds__Undefined_tr0(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Door__reeds__Undefined(handle);
	doorlock_enseq_main_region_Work_Door__reeds__Open_default(handle);
}

static void doorlock_effect_main_region_Work_Door__reeds__Undefined_tr1(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Door__reeds__Undefined(handle);
	doorlock_enseq_main_region_Work_Door__reeds__Closed_default(handle);
}

static void doorlock_effect_main_region_Work_Led_Off_tr0(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Led_Off(handle);
	doorlock_enseq_main_region_Work_Led_On_default(handle);
}

static void doorlock_effect_main_region_Work_Led_Off_tr1(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Led_Off(handle);
	doorlock_enseq_main_region_Work_Led_Blinking1_default(handle);
}

static void doorlock_effect_main_region_Work_Led_Off_tr2(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Led_Off(handle);
	doorlock_enseq_main_region_Work_Led_Blinking2_default(handle);
}

static void doorlock_effect_main_region_Work_Led_On_tr0(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Led_On(handle);
	doorlock_enseq_main_region_Work_Led_Off_default(handle);
}

static void doorlock_effect_main_region_Work_Led_Blinking1_tr0(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Led_Blinking1(handle);
	doorlock_enseq_main_region_Work_Led_Off_default(handle);
}

static void doorlock_effect_main_region_Work_Led_Blinking1_tr1(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Led_Blinking1(handle);
	doorlock_enseq_main_region_Work_Led_On_default(handle);
}

static void doorlock_effect_main_region_Work_Led_Blinking2_tr0(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Led_Blinking2(handle);
	doorlock_enseq_main_region_Work_Led_Off_default(handle);
}

static void doorlock_effect_main_region_Work_Led_Blinking2_tr1(Doorlock* handle)
{
	doorlock_exseq_main_region_Work_Led_Blinking2(handle);
	doorlock_enseq_main_region_Work_Led_On_default(handle);
}

static void doorlock_effect_main_region_Configure_tr0(Doorlock* handle)
{
	doorlock_exseq_main_region_Configure(handle);
	doorlock_enseq_main_region_Work_default(handle);
}

/* Entry action for state 'WaitConnect'. */
static void doorlock_enact_main_region_WaitConnect(Doorlock* handle)
{
	/* Entry action for state 'WaitConnect'. */
	doorlock_setTimer(handle, (sc_eventid) &(handle->timeEvents.doorlock_main_region_WaitConnect_tev0_raised) , 10 * 1000, bool_false);
}

/* Entry action for state 'CommandExec'. */
static void doorlock_enact_main_region_Work_Transmitter_CommandExec(Doorlock* handle)
{
	/* Entry action for state 'CommandExec'. */
	doorlock_setTimer(handle, (sc_eventid) &(handle->timeEvents.doorlock_main_region_Work_Transmitter_CommandExec_tev0_raised) , handle->ifaceCommands.timeout * 1000, bool_false);
}

/* Entry action for state 'Pressed'. */
static void doorlock_enact_main_region_Work_Buttons_Pressed(Doorlock* handle)
{
	/* Entry action for state 'Pressed'. */
	doorlock_setTimer(handle, (sc_eventid) &(handle->timeEvents.doorlock_main_region_Work_Buttons_Pressed_tev0_raised) , 1 * 1000, bool_false);
	handle->ifaceLock.ChangeState_raised = bool_true;
}

/* Entry action for state 'Open'. */
static void doorlock_enact_main_region_Work_Locks_Open(Doorlock* handle)
{
	/* Entry action for state 'Open'. */
	doorlockIfaceLock_closeLock1(handle);
}

/* Entry action for state 'Closed'. */
static void doorlock_enact_main_region_Work_Locks_Closed(Doorlock* handle)
{
	/* Entry action for state 'Closed'. */
	doorlockIfaceLock_closeLock2(handle);
}

/* Entry action for state 'Open'. */
static void doorlock_enact_main_region_Work_Door__reeds__Open(Doorlock* handle)
{
	/* Entry action for state 'Open'. */
	handle->ifaceTrans.comComplete_raised = bool_true;
	handle->ifaceLed.LedOff_raised = bool_true;
}

/* Entry action for state 'Closed'. */
static void doorlock_enact_main_region_Work_Door__reeds__Closed(Doorlock* handle)
{
	/* Entry action for state 'Closed'. */
	handle->ifaceTrans.comComplete_raised = bool_true;
	handle->ifaceLed.LedOn_raised = bool_true;
}

/* Entry action for state 'Undefined'. */
static void doorlock_enact_main_region_Work_Door__reeds__Undefined(Doorlock* handle)
{
	/* Entry action for state 'Undefined'. */
	handle->ifaceLed.LedBlinking1_raised = bool_true;
}

/* Exit action for state 'WaitConnect'. */
static void doorlock_exact_main_region_WaitConnect(Doorlock* handle)
{
	/* Exit action for state 'WaitConnect'. */
	doorlock_unsetTimer(handle, (sc_eventid) &(handle->timeEvents.doorlock_main_region_WaitConnect_tev0_raised) );		
}

/* Exit action for state 'CommandExec'. */
static void doorlock_exact_main_region_Work_Transmitter_CommandExec(Doorlock* handle)
{
	/* Exit action for state 'CommandExec'. */
	doorlock_unsetTimer(handle, (sc_eventid) &(handle->timeEvents.doorlock_main_region_Work_Transmitter_CommandExec_tev0_raised) );		
}

/* Exit action for state 'Pressed'. */
static void doorlock_exact_main_region_Work_Buttons_Pressed(Doorlock* handle)
{
	/* Exit action for state 'Pressed'. */
	doorlock_unsetTimer(handle, (sc_eventid) &(handle->timeEvents.doorlock_main_region_Work_Buttons_Pressed_tev0_raised) );		
}

/* Exit action for state 'Open'. */
static void doorlock_exact_main_region_Work_Locks_Open(Doorlock* handle)
{
	/* Exit action for state 'Open'. */
	doorlockIfaceLock_openLock1(handle);
}

/* Exit action for state 'Closed'. */
static void doorlock_exact_main_region_Work_Locks_Closed(Doorlock* handle)
{
	/* Exit action for state 'Closed'. */
	doorlockIfaceLock_openLock2(handle);
}

/* 'default' enter sequence for state Init */
static void doorlock_enseq_main_region_Init_default(Doorlock* handle)
{
	/* 'default' enter sequence for state Init */
	handle->stateConfVector[0] = Doorlock_main_region_Init;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state WaitConnect */
static void doorlock_enseq_main_region_WaitConnect_default(Doorlock* handle)
{
	/* 'default' enter sequence for state WaitConnect */
	doorlock_enact_main_region_WaitConnect(handle);
	handle->stateConfVector[0] = Doorlock_main_region_WaitConnect;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state Work */
static void doorlock_enseq_main_region_Work_default(Doorlock* handle)
{
	/* 'default' enter sequence for state Work */
	doorlock_enseq_main_region_Work_Transmitter_default(handle);
	doorlock_enseq_main_region_Work_Buttons_default(handle);
	doorlock_enseq_main_region_Work_Locks_default(handle);
	doorlock_enseq_main_region_Work_Door__reeds__default(handle);
	doorlock_enseq_main_region_Work_Led_default(handle);
}

/* 'default' enter sequence for state Idle */
static void doorlock_enseq_main_region_Work_Transmitter_Idle_default(Doorlock* handle)
{
	/* 'default' enter sequence for state Idle */
	handle->stateConfVector[0] = Doorlock_main_region_Work_Transmitter_Idle;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state CommandExec */
static void doorlock_enseq_main_region_Work_Transmitter_CommandExec_default(Doorlock* handle)
{
	/* 'default' enter sequence for state CommandExec */
	doorlock_enact_main_region_Work_Transmitter_CommandExec(handle);
	handle->stateConfVector[0] = Doorlock_main_region_Work_Transmitter_CommandExec;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state SendTimeout */
static void doorlock_enseq_main_region_Work_Transmitter_SendTimeout_default(Doorlock* handle)
{
	/* 'default' enter sequence for state SendTimeout */
	handle->stateConfVector[0] = Doorlock_main_region_Work_Transmitter_SendTimeout;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state CommandSucc */
static void doorlock_enseq_main_region_Work_Transmitter_CommandSucc_default(Doorlock* handle)
{
	/* 'default' enter sequence for state CommandSucc */
	handle->stateConfVector[0] = Doorlock_main_region_Work_Transmitter_CommandSucc;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state Idle */
static void doorlock_enseq_main_region_Work_Buttons_Idle_default(Doorlock* handle)
{
	/* 'default' enter sequence for state Idle */
	handle->stateConfVector[1] = Doorlock_main_region_Work_Buttons_Idle;
	handle->stateConfVectorPosition = 1;
}

/* 'default' enter sequence for state Pressed */
static void doorlock_enseq_main_region_Work_Buttons_Pressed_default(Doorlock* handle)
{
	/* 'default' enter sequence for state Pressed */
	doorlock_enact_main_region_Work_Buttons_Pressed(handle);
	handle->stateConfVector[1] = Doorlock_main_region_Work_Buttons_Pressed;
	handle->stateConfVectorPosition = 1;
}

/* 'default' enter sequence for state Open */
static void doorlock_enseq_main_region_Work_Locks_Open_default(Doorlock* handle)
{
	/* 'default' enter sequence for state Open */
	doorlock_enact_main_region_Work_Locks_Open(handle);
	handle->stateConfVector[2] = Doorlock_main_region_Work_Locks_Open;
	handle->stateConfVectorPosition = 2;
}

/* 'default' enter sequence for state Closed */
static void doorlock_enseq_main_region_Work_Locks_Closed_default(Doorlock* handle)
{
	/* 'default' enter sequence for state Closed */
	doorlock_enact_main_region_Work_Locks_Closed(handle);
	handle->stateConfVector[2] = Doorlock_main_region_Work_Locks_Closed;
	handle->stateConfVectorPosition = 2;
}

/* 'default' enter sequence for state inProcess */
static void doorlock_enseq_main_region_Work_Locks_inProcess_default(Doorlock* handle)
{
	/* 'default' enter sequence for state inProcess */
	handle->stateConfVector[2] = Doorlock_main_region_Work_Locks_inProcess;
	handle->stateConfVectorPosition = 2;
}

/* 'default' enter sequence for state Open */
static void doorlock_enseq_main_region_Work_Door__reeds__Open_default(Doorlock* handle)
{
	/* 'default' enter sequence for state Open */
	doorlock_enact_main_region_Work_Door__reeds__Open(handle);
	handle->stateConfVector[3] = Doorlock_main_region_Work_Door__reeds__Open;
	handle->stateConfVectorPosition = 3;
}

/* 'default' enter sequence for state Closed */
static void doorlock_enseq_main_region_Work_Door__reeds__Closed_default(Doorlock* handle)
{
	/* 'default' enter sequence for state Closed */
	doorlock_enact_main_region_Work_Door__reeds__Closed(handle);
	handle->stateConfVector[3] = Doorlock_main_region_Work_Door__reeds__Closed;
	handle->stateConfVectorPosition = 3;
}

/* 'default' enter sequence for state Undefined */
static void doorlock_enseq_main_region_Work_Door__reeds__Undefined_default(Doorlock* handle)
{
	/* 'default' enter sequence for state Undefined */
	doorlock_enact_main_region_Work_Door__reeds__Undefined(handle);
	handle->stateConfVector[3] = Doorlock_main_region_Work_Door__reeds__Undefined;
	handle->stateConfVectorPosition = 3;
}

/* 'default' enter sequence for state Off */
static void doorlock_enseq_main_region_Work_Led_Off_default(Doorlock* handle)
{
	/* 'default' enter sequence for state Off */
	handle->stateConfVector[4] = Doorlock_main_region_Work_Led_Off;
	handle->stateConfVectorPosition = 4;
}

/* 'default' enter sequence for state On */
static void doorlock_enseq_main_region_Work_Led_On_default(Doorlock* handle)
{
	/* 'default' enter sequence for state On */
	handle->stateConfVector[4] = Doorlock_main_region_Work_Led_On;
	handle->stateConfVectorPosition = 4;
}

/* 'default' enter sequence for state Blinking1 */
static void doorlock_enseq_main_region_Work_Led_Blinking1_default(Doorlock* handle)
{
	/* 'default' enter sequence for state Blinking1 */
	handle->stateConfVector[4] = Doorlock_main_region_Work_Led_Blinking1;
	handle->stateConfVectorPosition = 4;
}

/* 'default' enter sequence for state Blinking2 */
static void doorlock_enseq_main_region_Work_Led_Blinking2_default(Doorlock* handle)
{
	/* 'default' enter sequence for state Blinking2 */
	handle->stateConfVector[4] = Doorlock_main_region_Work_Led_Blinking2;
	handle->stateConfVectorPosition = 4;
}

/* 'default' enter sequence for state Configure */
static void doorlock_enseq_main_region_Configure_default(Doorlock* handle)
{
	/* 'default' enter sequence for state Configure */
	handle->stateConfVector[0] = Doorlock_main_region_Configure;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for region main region */
static void doorlock_enseq_main_region_default(Doorlock* handle)
{
	/* 'default' enter sequence for region main region */
	doorlock_react_main_region__entry_Default(handle);
}

/* 'default' enter sequence for region Transmitter */
static void doorlock_enseq_main_region_Work_Transmitter_default(Doorlock* handle)
{
	/* 'default' enter sequence for region Transmitter */
	doorlock_react_main_region_Work_Transmitter__entry_Default(handle);
}

/* 'default' enter sequence for region Buttons */
static void doorlock_enseq_main_region_Work_Buttons_default(Doorlock* handle)
{
	/* 'default' enter sequence for region Buttons */
	doorlock_react_main_region_Work_Buttons__entry_Default(handle);
}

/* 'default' enter sequence for region Locks */
static void doorlock_enseq_main_region_Work_Locks_default(Doorlock* handle)
{
	/* 'default' enter sequence for region Locks */
	doorlock_react_main_region_Work_Locks__entry_Default(handle);
}

/* 'default' enter sequence for region Door (reeds) */
static void doorlock_enseq_main_region_Work_Door__reeds__default(Doorlock* handle)
{
	/* 'default' enter sequence for region Door (reeds) */
	doorlock_react_main_region_Work_Door__reeds___entry_Default(handle);
}

/* 'default' enter sequence for region Led */
static void doorlock_enseq_main_region_Work_Led_default(Doorlock* handle)
{
	/* 'default' enter sequence for region Led */
	doorlock_react_main_region_Work_Led__entry_Default(handle);
}

/* Default exit sequence for state Init */
static void doorlock_exseq_main_region_Init(Doorlock* handle)
{
	/* Default exit sequence for state Init */
	handle->stateConfVector[0] = Doorlock_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state WaitConnect */
static void doorlock_exseq_main_region_WaitConnect(Doorlock* handle)
{
	/* Default exit sequence for state WaitConnect */
	handle->stateConfVector[0] = Doorlock_last_state;
	handle->stateConfVectorPosition = 0;
	doorlock_exact_main_region_WaitConnect(handle);
}

/* Default exit sequence for state Idle */
static void doorlock_exseq_main_region_Work_Transmitter_Idle(Doorlock* handle)
{
	/* Default exit sequence for state Idle */
	handle->stateConfVector[0] = Doorlock_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state CommandExec */
static void doorlock_exseq_main_region_Work_Transmitter_CommandExec(Doorlock* handle)
{
	/* Default exit sequence for state CommandExec */
	handle->stateConfVector[0] = Doorlock_last_state;
	handle->stateConfVectorPosition = 0;
	doorlock_exact_main_region_Work_Transmitter_CommandExec(handle);
}

/* Default exit sequence for state SendTimeout */
static void doorlock_exseq_main_region_Work_Transmitter_SendTimeout(Doorlock* handle)
{
	/* Default exit sequence for state SendTimeout */
	handle->stateConfVector[0] = Doorlock_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state CommandSucc */
static void doorlock_exseq_main_region_Work_Transmitter_CommandSucc(Doorlock* handle)
{
	/* Default exit sequence for state CommandSucc */
	handle->stateConfVector[0] = Doorlock_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for state Idle */
static void doorlock_exseq_main_region_Work_Buttons_Idle(Doorlock* handle)
{
	/* Default exit sequence for state Idle */
	handle->stateConfVector[1] = Doorlock_last_state;
	handle->stateConfVectorPosition = 1;
}

/* Default exit sequence for state Pressed */
static void doorlock_exseq_main_region_Work_Buttons_Pressed(Doorlock* handle)
{
	/* Default exit sequence for state Pressed */
	handle->stateConfVector[1] = Doorlock_last_state;
	handle->stateConfVectorPosition = 1;
	doorlock_exact_main_region_Work_Buttons_Pressed(handle);
}

/* Default exit sequence for state Open */
static void doorlock_exseq_main_region_Work_Locks_Open(Doorlock* handle)
{
	/* Default exit sequence for state Open */
	handle->stateConfVector[2] = Doorlock_last_state;
	handle->stateConfVectorPosition = 2;
	doorlock_exact_main_region_Work_Locks_Open(handle);
}

/* Default exit sequence for state Closed */
static void doorlock_exseq_main_region_Work_Locks_Closed(Doorlock* handle)
{
	/* Default exit sequence for state Closed */
	handle->stateConfVector[2] = Doorlock_last_state;
	handle->stateConfVectorPosition = 2;
	doorlock_exact_main_region_Work_Locks_Closed(handle);
}

/* Default exit sequence for state inProcess */
static void doorlock_exseq_main_region_Work_Locks_inProcess(Doorlock* handle)
{
	/* Default exit sequence for state inProcess */
	handle->stateConfVector[2] = Doorlock_last_state;
	handle->stateConfVectorPosition = 2;
}

/* Default exit sequence for state Open */
static void doorlock_exseq_main_region_Work_Door__reeds__Open(Doorlock* handle)
{
	/* Default exit sequence for state Open */
	handle->stateConfVector[3] = Doorlock_last_state;
	handle->stateConfVectorPosition = 3;
}

/* Default exit sequence for state Closed */
static void doorlock_exseq_main_region_Work_Door__reeds__Closed(Doorlock* handle)
{
	/* Default exit sequence for state Closed */
	handle->stateConfVector[3] = Doorlock_last_state;
	handle->stateConfVectorPosition = 3;
}

/* Default exit sequence for state Undefined */
static void doorlock_exseq_main_region_Work_Door__reeds__Undefined(Doorlock* handle)
{
	/* Default exit sequence for state Undefined */
	handle->stateConfVector[3] = Doorlock_last_state;
	handle->stateConfVectorPosition = 3;
}

/* Default exit sequence for state Off */
static void doorlock_exseq_main_region_Work_Led_Off(Doorlock* handle)
{
	/* Default exit sequence for state Off */
	handle->stateConfVector[4] = Doorlock_last_state;
	handle->stateConfVectorPosition = 4;
}

/* Default exit sequence for state On */
static void doorlock_exseq_main_region_Work_Led_On(Doorlock* handle)
{
	/* Default exit sequence for state On */
	handle->stateConfVector[4] = Doorlock_last_state;
	handle->stateConfVectorPosition = 4;
}

/* Default exit sequence for state Blinking1 */
static void doorlock_exseq_main_region_Work_Led_Blinking1(Doorlock* handle)
{
	/* Default exit sequence for state Blinking1 */
	handle->stateConfVector[4] = Doorlock_last_state;
	handle->stateConfVectorPosition = 4;
}

/* Default exit sequence for state Blinking2 */
static void doorlock_exseq_main_region_Work_Led_Blinking2(Doorlock* handle)
{
	/* Default exit sequence for state Blinking2 */
	handle->stateConfVector[4] = Doorlock_last_state;
	handle->stateConfVectorPosition = 4;
}

/* Default exit sequence for state Configure */
static void doorlock_exseq_main_region_Configure(Doorlock* handle)
{
	/* Default exit sequence for state Configure */
	handle->stateConfVector[0] = Doorlock_last_state;
	handle->stateConfVectorPosition = 0;
}

/* Default exit sequence for region main region */
static void doorlock_exseq_main_region(Doorlock* handle)
{
	/* Default exit sequence for region main region */
	/* Handle exit of all possible states (of Doorlock.main_region) at position 0... */
	switch(handle->stateConfVector[ 0 ])
	{
		case Doorlock_main_region_Init :
		{
			doorlock_exseq_main_region_Init(handle);
			break;
		}
		case Doorlock_main_region_WaitConnect :
		{
			doorlock_exseq_main_region_WaitConnect(handle);
			break;
		}
		case Doorlock_main_region_Work_Transmitter_Idle :
		{
			doorlock_exseq_main_region_Work_Transmitter_Idle(handle);
			break;
		}
		case Doorlock_main_region_Work_Transmitter_CommandExec :
		{
			doorlock_exseq_main_region_Work_Transmitter_CommandExec(handle);
			break;
		}
		case Doorlock_main_region_Work_Transmitter_SendTimeout :
		{
			doorlock_exseq_main_region_Work_Transmitter_SendTimeout(handle);
			break;
		}
		case Doorlock_main_region_Work_Transmitter_CommandSucc :
		{
			doorlock_exseq_main_region_Work_Transmitter_CommandSucc(handle);
			break;
		}
		case Doorlock_main_region_Configure :
		{
			doorlock_exseq_main_region_Configure(handle);
			break;
		}
		default: break;
	}
	/* Handle exit of all possible states (of Doorlock.main_region) at position 1... */
	switch(handle->stateConfVector[ 1 ])
	{
		case Doorlock_main_region_Work_Buttons_Idle :
		{
			doorlock_exseq_main_region_Work_Buttons_Idle(handle);
			break;
		}
		case Doorlock_main_region_Work_Buttons_Pressed :
		{
			doorlock_exseq_main_region_Work_Buttons_Pressed(handle);
			break;
		}
		default: break;
	}
	/* Handle exit of all possible states (of Doorlock.main_region) at position 2... */
	switch(handle->stateConfVector[ 2 ])
	{
		case Doorlock_main_region_Work_Locks_Open :
		{
			doorlock_exseq_main_region_Work_Locks_Open(handle);
			break;
		}
		case Doorlock_main_region_Work_Locks_Closed :
		{
			doorlock_exseq_main_region_Work_Locks_Closed(handle);
			break;
		}
		case Doorlock_main_region_Work_Locks_inProcess :
		{
			doorlock_exseq_main_region_Work_Locks_inProcess(handle);
			break;
		}
		default: break;
	}
	/* Handle exit of all possible states (of Doorlock.main_region) at position 3... */
	switch(handle->stateConfVector[ 3 ])
	{
		case Doorlock_main_region_Work_Door__reeds__Open :
		{
			doorlock_exseq_main_region_Work_Door__reeds__Open(handle);
			break;
		}
		case Doorlock_main_region_Work_Door__reeds__Closed :
		{
			doorlock_exseq_main_region_Work_Door__reeds__Closed(handle);
			break;
		}
		case Doorlock_main_region_Work_Door__reeds__Undefined :
		{
			doorlock_exseq_main_region_Work_Door__reeds__Undefined(handle);
			break;
		}
		default: break;
	}
	/* Handle exit of all possible states (of Doorlock.main_region) at position 4... */
	switch(handle->stateConfVector[ 4 ])
	{
		case Doorlock_main_region_Work_Led_Off :
		{
			doorlock_exseq_main_region_Work_Led_Off(handle);
			break;
		}
		case Doorlock_main_region_Work_Led_On :
		{
			doorlock_exseq_main_region_Work_Led_On(handle);
			break;
		}
		case Doorlock_main_region_Work_Led_Blinking1 :
		{
			doorlock_exseq_main_region_Work_Led_Blinking1(handle);
			break;
		}
		case Doorlock_main_region_Work_Led_Blinking2 :
		{
			doorlock_exseq_main_region_Work_Led_Blinking2(handle);
			break;
		}
		default: break;
	}
}

/* Default exit sequence for region Transmitter */
static void doorlock_exseq_main_region_Work_Transmitter(Doorlock* handle)
{
	/* Default exit sequence for region Transmitter */
	/* Handle exit of all possible states (of Doorlock.main_region.Work.Transmitter) at position 0... */
	switch(handle->stateConfVector[ 0 ])
	{
		case Doorlock_main_region_Work_Transmitter_Idle :
		{
			doorlock_exseq_main_region_Work_Transmitter_Idle(handle);
			break;
		}
		case Doorlock_main_region_Work_Transmitter_CommandExec :
		{
			doorlock_exseq_main_region_Work_Transmitter_CommandExec(handle);
			break;
		}
		case Doorlock_main_region_Work_Transmitter_SendTimeout :
		{
			doorlock_exseq_main_region_Work_Transmitter_SendTimeout(handle);
			break;
		}
		case Doorlock_main_region_Work_Transmitter_CommandSucc :
		{
			doorlock_exseq_main_region_Work_Transmitter_CommandSucc(handle);
			break;
		}
		default: break;
	}
}

/* Default exit sequence for region Buttons */
static void doorlock_exseq_main_region_Work_Buttons(Doorlock* handle)
{
	/* Default exit sequence for region Buttons */
	/* Handle exit of all possible states (of Doorlock.main_region.Work.Buttons) at position 1... */
	switch(handle->stateConfVector[ 1 ])
	{
		case Doorlock_main_region_Work_Buttons_Idle :
		{
			doorlock_exseq_main_region_Work_Buttons_Idle(handle);
			break;
		}
		case Doorlock_main_region_Work_Buttons_Pressed :
		{
			doorlock_exseq_main_region_Work_Buttons_Pressed(handle);
			break;
		}
		default: break;
	}
}

/* Default exit sequence for region Locks */
static void doorlock_exseq_main_region_Work_Locks(Doorlock* handle)
{
	/* Default exit sequence for region Locks */
	/* Handle exit of all possible states (of Doorlock.main_region.Work.Locks) at position 2... */
	switch(handle->stateConfVector[ 2 ])
	{
		case Doorlock_main_region_Work_Locks_Open :
		{
			doorlock_exseq_main_region_Work_Locks_Open(handle);
			break;
		}
		case Doorlock_main_region_Work_Locks_Closed :
		{
			doorlock_exseq_main_region_Work_Locks_Closed(handle);
			break;
		}
		case Doorlock_main_region_Work_Locks_inProcess :
		{
			doorlock_exseq_main_region_Work_Locks_inProcess(handle);
			break;
		}
		default: break;
	}
}

/* Default exit sequence for region Door (reeds) */
static void doorlock_exseq_main_region_Work_Door__reeds_(Doorlock* handle)
{
	/* Default exit sequence for region Door (reeds) */
	/* Handle exit of all possible states (of Doorlock.main_region.Work.Door__reeds_) at position 3... */
	switch(handle->stateConfVector[ 3 ])
	{
		case Doorlock_main_region_Work_Door__reeds__Open :
		{
			doorlock_exseq_main_region_Work_Door__reeds__Open(handle);
			break;
		}
		case Doorlock_main_region_Work_Door__reeds__Closed :
		{
			doorlock_exseq_main_region_Work_Door__reeds__Closed(handle);
			break;
		}
		case Doorlock_main_region_Work_Door__reeds__Undefined :
		{
			doorlock_exseq_main_region_Work_Door__reeds__Undefined(handle);
			break;
		}
		default: break;
	}
}

/* Default exit sequence for region Led */
static void doorlock_exseq_main_region_Work_Led(Doorlock* handle)
{
	/* Default exit sequence for region Led */
	/* Handle exit of all possible states (of Doorlock.main_region.Work.Led) at position 4... */
	switch(handle->stateConfVector[ 4 ])
	{
		case Doorlock_main_region_Work_Led_Off :
		{
			doorlock_exseq_main_region_Work_Led_Off(handle);
			break;
		}
		case Doorlock_main_region_Work_Led_On :
		{
			doorlock_exseq_main_region_Work_Led_On(handle);
			break;
		}
		case Doorlock_main_region_Work_Led_Blinking1 :
		{
			doorlock_exseq_main_region_Work_Led_Blinking1(handle);
			break;
		}
		case Doorlock_main_region_Work_Led_Blinking2 :
		{
			doorlock_exseq_main_region_Work_Led_Blinking2(handle);
			break;
		}
		default: break;
	}
}

/* The reactions of state Init. */
static void doorlock_react_main_region_Init(Doorlock* handle)
{
	/* The reactions of state Init. */
	if (doorlock_check_main_region_Init_tr0_tr0(handle) == bool_true)
	{ 
		doorlock_effect_main_region_Init_tr0(handle);
	} 
}

/* The reactions of state WaitConnect. */
static void doorlock_react_main_region_WaitConnect(Doorlock* handle)
{
	/* The reactions of state WaitConnect. */
	if (doorlock_check_main_region_WaitConnect_tr0_tr0(handle) == bool_true)
	{ 
		doorlock_effect_main_region_WaitConnect_tr0(handle);
	}  else
	{
		if (doorlock_check_main_region_WaitConnect_tr1_tr1(handle) == bool_true)
		{ 
			doorlock_effect_main_region_WaitConnect_tr1(handle);
		}  else
		{
			if (doorlock_check_main_region_WaitConnect_tr2_tr2(handle) == bool_true)
			{ 
				doorlock_effect_main_region_WaitConnect_tr2(handle);
			} 
		}
	}
}

/* The reactions of state Idle. */
static void doorlock_react_main_region_Work_Transmitter_Idle(Doorlock* handle)
{
	/* The reactions of state Idle. */
	if (doorlock_check_main_region_Work_Transmitter_Idle_tr0_tr0(handle) == bool_true)
	{ 
		doorlock_effect_main_region_Work_Transmitter_Idle_tr0(handle);
	} 
}

/* The reactions of state CommandExec. */
static void doorlock_react_main_region_Work_Transmitter_CommandExec(Doorlock* handle)
{
	/* The reactions of state CommandExec. */
	if (doorlock_check_main_region_Work_Transmitter_CommandExec_tr0_tr0(handle) == bool_true)
	{ 
		doorlock_effect_main_region_Work_Transmitter_CommandExec_tr0(handle);
	}  else
	{
		if (doorlock_check_main_region_Work_Transmitter_CommandExec_tr1_tr1(handle) == bool_true)
		{ 
			doorlock_effect_main_region_Work_Transmitter_CommandExec_tr1(handle);
		} 
	}
}

/* The reactions of state SendTimeout. */
static void doorlock_react_main_region_Work_Transmitter_SendTimeout(Doorlock* handle)
{
	/* The reactions of state SendTimeout. */
	if (doorlock_check_main_region_Work_Transmitter_SendTimeout_tr0_tr0(handle) == bool_true)
	{ 
		doorlock_effect_main_region_Work_Transmitter_SendTimeout_tr0(handle);
	} 
}

/* The reactions of state CommandSucc. */
static void doorlock_react_main_region_Work_Transmitter_CommandSucc(Doorlock* handle)
{
	/* The reactions of state CommandSucc. */
	if (doorlock_check_main_region_Work_Transmitter_CommandSucc_tr0_tr0(handle) == bool_true)
	{ 
		doorlock_effect_main_region_Work_Transmitter_CommandSucc_tr0(handle);
	} 
}

/* The reactions of state Idle. */
static void doorlock_react_main_region_Work_Buttons_Idle(Doorlock* handle)
{
	/* The reactions of state Idle. */
	if (doorlock_check_main_region_Work_Buttons_Idle_tr0_tr0(handle) == bool_true)
	{ 
		doorlock_effect_main_region_Work_Buttons_Idle_tr0(handle);
	}  else
	{
		if (doorlock_check_main_region_Work_Buttons_Idle_tr1_tr1(handle) == bool_true)
		{ 
			doorlock_effect_main_region_Work_Buttons_Idle_tr1(handle);
		} 
	}
}

/* The reactions of state Pressed. */
static void doorlock_react_main_region_Work_Buttons_Pressed(Doorlock* handle)
{
	/* The reactions of state Pressed. */
	if (doorlock_check_main_region_Work_Buttons_Pressed_tr0_tr0(handle) == bool_true)
	{ 
		doorlock_effect_main_region_Work_Buttons_Pressed_tr0(handle);
	} 
}

/* The reactions of state Open. */
static void doorlock_react_main_region_Work_Locks_Open(Doorlock* handle)
{
	/* The reactions of state Open. */
	if (doorlock_check_main_region_Work_Locks_Open_tr0_tr0(handle) == bool_true)
	{ 
		doorlock_effect_main_region_Work_Locks_Open_tr0(handle);
	}  else
	{
		if (doorlock_check_main_region_Work_Locks_Open_tr1_tr1(handle) == bool_true)
		{ 
			doorlock_effect_main_region_Work_Locks_Open_tr1(handle);
		} 
	}
}

/* The reactions of state Closed. */
static void doorlock_react_main_region_Work_Locks_Closed(Doorlock* handle)
{
	/* The reactions of state Closed. */
	if (doorlock_check_main_region_Work_Locks_Closed_tr0_tr0(handle) == bool_true)
	{ 
		doorlock_effect_main_region_Work_Locks_Closed_tr0(handle);
	}  else
	{
		if (doorlock_check_main_region_Work_Locks_Closed_tr1_tr1(handle) == bool_true)
		{ 
			doorlock_effect_main_region_Work_Locks_Closed_tr1(handle);
		} 
	}
}

/* The reactions of state inProcess. */
static void doorlock_react_main_region_Work_Locks_inProcess(Doorlock* handle)
{
	/* The reactions of state inProcess. */
	if (doorlock_check_main_region_Work_Locks_inProcess_tr0_tr0(handle) == bool_true)
	{ 
		doorlock_effect_main_region_Work_Locks_inProcess_tr0(handle);
	}  else
	{
		if (doorlock_check_main_region_Work_Locks_inProcess_tr1_tr1(handle) == bool_true)
		{ 
			doorlock_effect_main_region_Work_Locks_inProcess_tr1(handle);
		} 
	}
}

/* The reactions of state Open. */
static void doorlock_react_main_region_Work_Door__reeds__Open(Doorlock* handle)
{
	/* The reactions of state Open. */
	if (doorlock_check_main_region_Work_Door__reeds__Open_tr0_tr0(handle) == bool_true)
	{ 
		doorlock_effect_main_region_Work_Door__reeds__Open_tr0(handle);
	} 
}

/* The reactions of state Closed. */
static void doorlock_react_main_region_Work_Door__reeds__Closed(Doorlock* handle)
{
	/* The reactions of state Closed. */
	if (doorlock_check_main_region_Work_Door__reeds__Closed_tr0_tr0(handle) == bool_true)
	{ 
		doorlock_effect_main_region_Work_Door__reeds__Closed_tr0(handle);
	} 
}

/* The reactions of state Undefined. */
static void doorlock_react_main_region_Work_Door__reeds__Undefined(Doorlock* handle)
{
	/* The reactions of state Undefined. */
	if (doorlock_check_main_region_Work_Door__reeds__Undefined_tr0_tr0(handle) == bool_true)
	{ 
		doorlock_effect_main_region_Work_Door__reeds__Undefined_tr0(handle);
	}  else
	{
		if (doorlock_check_main_region_Work_Door__reeds__Undefined_tr1_tr1(handle) == bool_true)
		{ 
			doorlock_effect_main_region_Work_Door__reeds__Undefined_tr1(handle);
		} 
	}
}

/* The reactions of state Off. */
static void doorlock_react_main_region_Work_Led_Off(Doorlock* handle)
{
	/* The reactions of state Off. */
	if (doorlock_check_main_region_Work_Led_Off_tr0_tr0(handle) == bool_true)
	{ 
		doorlock_effect_main_region_Work_Led_Off_tr0(handle);
	}  else
	{
		if (doorlock_check_main_region_Work_Led_Off_tr1_tr1(handle) == bool_true)
		{ 
			doorlock_effect_main_region_Work_Led_Off_tr1(handle);
		}  else
		{
			if (doorlock_check_main_region_Work_Led_Off_tr2_tr2(handle) == bool_true)
			{ 
				doorlock_effect_main_region_Work_Led_Off_tr2(handle);
			} 
		}
	}
}

/* The reactions of state On. */
static void doorlock_react_main_region_Work_Led_On(Doorlock* handle)
{
	/* The reactions of state On. */
	if (doorlock_check_main_region_Work_Led_On_tr0_tr0(handle) == bool_true)
	{ 
		doorlock_effect_main_region_Work_Led_On_tr0(handle);
	} 
}

/* The reactions of state Blinking1. */
static void doorlock_react_main_region_Work_Led_Blinking1(Doorlock* handle)
{
	/* The reactions of state Blinking1. */
	if (doorlock_check_main_region_Work_Led_Blinking1_tr0_tr0(handle) == bool_true)
	{ 
		doorlock_effect_main_region_Work_Led_Blinking1_tr0(handle);
	}  else
	{
		if (doorlock_check_main_region_Work_Led_Blinking1_tr1_tr1(handle) == bool_true)
		{ 
			doorlock_effect_main_region_Work_Led_Blinking1_tr1(handle);
		} 
	}
}

/* The reactions of state Blinking2. */
static void doorlock_react_main_region_Work_Led_Blinking2(Doorlock* handle)
{
	/* The reactions of state Blinking2. */
	if (doorlock_check_main_region_Work_Led_Blinking2_tr0_tr0(handle) == bool_true)
	{ 
		doorlock_effect_main_region_Work_Led_Blinking2_tr0(handle);
	}  else
	{
		if (doorlock_check_main_region_Work_Led_Blinking2_tr1_tr1(handle) == bool_true)
		{ 
			doorlock_effect_main_region_Work_Led_Blinking2_tr1(handle);
		} 
	}
}

/* The reactions of state Configure. */
static void doorlock_react_main_region_Configure(Doorlock* handle)
{
	/* The reactions of state Configure. */
	if (doorlock_check_main_region_Configure_tr0_tr0(handle) == bool_true)
	{ 
		doorlock_effect_main_region_Configure_tr0(handle);
	} 
}

/* Default react sequence for initial entry  */
static void doorlock_react_main_region__entry_Default(Doorlock* handle)
{
	/* Default react sequence for initial entry  */
	doorlock_enseq_main_region_Init_default(handle);
}

/* Default react sequence for initial entry  */
static void doorlock_react_main_region_Work_Transmitter__entry_Default(Doorlock* handle)
{
	/* Default react sequence for initial entry  */
	doorlock_enseq_main_region_Work_Transmitter_Idle_default(handle);
}

/* Default react sequence for initial entry  */
static void doorlock_react_main_region_Work_Buttons__entry_Default(Doorlock* handle)
{
	/* Default react sequence for initial entry  */
	doorlock_enseq_main_region_Work_Buttons_Idle_default(handle);
}

/* Default react sequence for initial entry  */
static void doorlock_react_main_region_Work_Locks__entry_Default(Doorlock* handle)
{
	/* Default react sequence for initial entry  */
	doorlock_enseq_main_region_Work_Locks_Open_default(handle);
}

/* Default react sequence for initial entry  */
static void doorlock_react_main_region_Work_Door__reeds___entry_Default(Doorlock* handle)
{
	/* Default react sequence for initial entry  */
	doorlock_enseq_main_region_Work_Door__reeds__Open_default(handle);
}

/* Default react sequence for initial entry  */
static void doorlock_react_main_region_Work_Led__entry_Default(Doorlock* handle)
{
	/* Default react sequence for initial entry  */
	doorlock_enseq_main_region_Work_Led_Off_default(handle);
}


